"""
Nothing Control PC — Windows 10
USB connection is provided by: adb reverse tcp:8765 tcp:8765
Run: py pc_server.py
"""
import json
import socket
import ctypes
import subprocess
from pathlib import Path

HOST = "127.0.0.1"
PORT = 8765

# Change this token and use the same value in android/main.py.
TOKEN = "CHANGE_THIS_DAIZ_TOKEN"

# Only these applications can be launched from the phone.
APP_ALLOWLIST = {
    "notepad": ["notepad.exe"],
    "calculator": ["calc.exe"],
    "explorer": ["explorer.exe"],
    "paint": ["mspaint.exe"],
}

VK_VOLUME_UP = 0xAF
VK_VOLUME_DOWN = 0xAE
VK_VOLUME_MUTE = 0xAD
VK_CONTROL = 0x11
VK_C = 0x43
VK_V = 0x56
KEYEVENTF_KEYUP = 0x0002


def press_media_key(vk):
    user32 = ctypes.windll.user32
    user32.keybd_event(vk, 0, 0, 0)
    user32.keybd_event(vk, 0, KEYEVENTF_KEYUP, 0)


def press_shortcut(key):
    """Send Ctrl+C or Ctrl+V to the currently focused Windows application."""
    user32 = ctypes.windll.user32
    user32.keybd_event(VK_CONTROL, 0, 0, 0)
    user32.keybd_event(key, 0, 0, 0)
    user32.keybd_event(key, 0, KEYEVENTF_KEYUP, 0)
    user32.keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)


def handle_command(data):
    if data.get("token") != TOKEN:
        return {"ok": False, "error": "Unauthorized"}

    command = data.get("command")

    if command == "volume_up":
        press_media_key(VK_VOLUME_UP)
        return {"ok": True, "message": "Volume increased"}

    if command == "volume_down":
        press_media_key(VK_VOLUME_DOWN)
        return {"ok": True, "message": "Volume decreased"}

    if command == "mute":
        press_media_key(VK_VOLUME_MUTE)
        return {"ok": True, "message": "Mute toggled"}

    if command == "copy":
        press_shortcut(VK_C)
        return {"ok": True, "message": "Ctrl+C sent"}

    if command == "paste":
        press_shortcut(VK_V)
        return {"ok": True, "message": "Ctrl+V sent"}

    if command == "launch":
        app = data.get("app")
        executable = APP_ALLOWLIST.get(app)
        if not executable:
            return {"ok": False, "error": "Application is not allowed"}
        try:
            subprocess.Popen(executable, shell=False)
            return {"ok": True, "message": f"Started {app}"}
        except OSError as exc:
            return {"ok": False, "error": str(exc)}

    if command == "ping":
        return {"ok": True, "message": "Nothing Control PC is connected"}

    return {"ok": False, "error": "Unknown command"}


def serve_client(conn, address):
    with conn:
        conn.settimeout(5)
        file = conn.makefile("rwb")
        try:
            line = file.readline(8192)
            if not line:
                return
            try:
                request = json.loads(line.decode("utf-8"))
                response = handle_command(request)
            except (UnicodeDecodeError, json.JSONDecodeError):
                response = {"ok": False, "error": "Invalid request"}
            file.write((json.dumps(response) + "\n").encode("utf-8"))
            file.flush()
        except (OSError, TimeoutError):
            pass


def main():
    print("Nothing Control PC v1.0")
    print(f"Listening on {HOST}:{PORT}")
    print("Connect your phone with USB, enable USB debugging, then run:")
    print(f"adb reverse tcp:{PORT} tcp:{PORT}")
    print("Press Ctrl+C to stop.")
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((HOST, PORT))
        server.listen(5)
        while True:
            conn, address = server.accept()
            serve_client(conn, address)


if __name__ == "__main__":
    main()
