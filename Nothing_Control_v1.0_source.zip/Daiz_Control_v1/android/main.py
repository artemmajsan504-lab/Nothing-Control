"""Nothing Control v1.0 — Nothing-inspired monochrome Kivy interface."""
import json
import socket

from kivy.app import App
from kivy.metrics import dp
from kivy.graphics import Color, RoundedRectangle, Line
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.utils import get_color_from_hex

HOST = "127.0.0.1"
PORT = 8765
# Set the same private token in pc/pc_server.py
TOKEN = "CHANGE_THIS_DAIZ_TOKEN"

BG = get_color_from_hex("#080808")
CARD = get_color_from_hex("#171717")
CARD_PRESSED = get_color_from_hex("#292929")
WHITE = get_color_from_hex("#F5F5F2")
MUTED = get_color_from_hex("#92928E")
RED = get_color_from_hex("#E53935")
GREEN = get_color_from_hex("#C9F36A")


def send_command(command, app=None):
    payload = {"token": TOKEN, "command": command}
    if app:
        payload["app"] = app
    try:
        with socket.create_connection((HOST, PORT), timeout=2) as sock:
            sock.sendall((json.dumps(payload) + "\n").encode("utf-8"))
            stream = sock.makefile("rb")
            response = json.loads(stream.readline().decode("utf-8"))
            return response.get("message", response.get("error", "Неизвестный ответ")), response.get("ok", False)
    except (OSError, ValueError):
        return "Нет связи · проверь USB и ADB", False


class DotLabel(Label):
    """Small mono-style label used for the Nothing-like technical UI."""


class DaizButton(Button):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.background_normal = ""
        self.background_down = ""
        self.background_color = (0, 0, 0, 0)
        self.color = WHITE
        self.halign = "center"
        self.valign = "middle"
        self.bind(pos=self._draw, size=self._draw, state=self._draw)
        self._draw()

    def _draw(self, *_):
        self.canvas.before.clear()
        with self.canvas.before:
            Color(*(CARD_PRESSED if self.state == "down" else CARD))
            RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(18)])
            Color(*get_color_from_hex("#303030"))
            Line(rounded_rectangle=(self.x, self.y, self.width, self.height, dp(18)), width=0.8)


class DaizControlApp(App):
    def build(self):
        self.title = "Nothing Control v1.0"
        root = BoxLayout(orientation="vertical", padding=[dp(18), dp(14), dp(18), dp(12)], spacing=dp(10))
        with root.canvas.before:
            Color(*BG)
            self.bg_rect = RoundedRectangle(pos=root.pos, size=root.size, radius=[0])
        root.bind(pos=self._update_bg, size=self._update_bg)

        # Header / dot-matrix inspired identity
        header = BoxLayout(orientation="horizontal", size_hint_y=None, height=dp(62), spacing=dp(10))
        brand = BoxLayout(orientation="vertical", spacing=dp(0))
        brand.add_widget(Label(text="NOTHING CONTROL", color=WHITE, bold=True,
                               font_size="21sp", halign="left", valign="bottom",
                               text_size=(None, None)))
        brand.add_widget(Label(text="USB REMOTE  /  WINDOWS 10", color=MUTED,
                               font_size="9sp", halign="left", valign="top"))
        header.add_widget(brand)
        glyph = Label(text="●  ●\n●  ●", color=RED, font_size="13sp",
                      size_hint_x=None, width=dp(48), halign="center")
        header.add_widget(glyph)
        root.add_widget(header)

        # Scrollable content for smaller phone displays
        scroll = ScrollView(do_scroll_x=False, bar_width=dp(2))
        content = BoxLayout(orientation="vertical", spacing=dp(13), size_hint_y=None)
        content.bind(minimum_height=content.setter("height"))

        status_card = BoxLayout(orientation="horizontal", padding=[dp(14), dp(9)],
                                spacing=dp(9), size_hint_y=None, height=dp(58))
        self.status_dot = Label(text="●", color=RED, font_size="17sp", size_hint_x=None, width=dp(22))
        status_card.add_widget(self.status_dot)
        status_stack = BoxLayout(orientation="vertical", spacing=dp(1))
        status_stack.add_widget(Label(text="PC CONNECTION", color=MUTED, font_size="9sp", halign="left"))
        self.status = Label(text="NOT CONNECTED", color=WHITE, font_size="13sp", bold=True, halign="left")
        status_stack.add_widget(self.status)
        status_card.add_widget(status_stack)
        self._panel_background(status_card)
        content.add_widget(status_card)

        content.add_widget(self.section("01  /  AUDIO"))
        volume = GridLayout(cols=3, spacing=dp(9), size_hint_y=None, height=dp(100))
        volume.add_widget(self.action_button("−", "VOLUME DOWN", lambda *_: self.run("volume_down"), 27))
        volume.add_widget(self.action_button("×", "MUTE", lambda *_: self.run("mute"), 22, accent=True))
        volume.add_widget(self.action_button("+", "VOLUME UP", lambda *_: self.run("volume_up"), 27))
        content.add_widget(volume)

        content.add_widget(self.section("02  /  APPLICATIONS"))
        apps = GridLayout(cols=2, spacing=dp(9), size_hint_y=None, height=dp(196))
        apps.add_widget(self.action_button("▤\nNOTEPAD", "", lambda *_: self.run("launch", "notepad"), 17))
        apps.add_widget(self.action_button("▦\nCALCULATOR", "", lambda *_: self.run("launch", "calculator"), 17))
        apps.add_widget(self.action_button("▣\nEXPLORER", "", lambda *_: self.run("launch", "explorer"), 17))
        apps.add_widget(self.action_button("◩\nPAINT", "", lambda *_: self.run("launch", "paint"), 17))
        content.add_widget(apps)

        content.add_widget(self.section("03  /  QUICK ACTIONS"))
        shortcuts = GridLayout(cols=2, spacing=dp(9), size_hint_y=None, height=dp(100))
        shortcuts.add_widget(self.action_button("⧉\\nCOPY", "CTRL + C",
                                                 lambda *_: self.run("copy"), 17))
        shortcuts.add_widget(self.action_button("▣\\nPASTE", "CTRL + V",
                                                 lambda *_: self.run("paste"), 17))
        content.add_widget(shortcuts)

        content.add_widget(self.section("04  /  CONNECTION"))
        check = self.action_button("CHECK USB CONNECTION", "PING PC", lambda *_: self.run("ping"), 14, accent=True)
        check.size_hint_y = None
        check.height = dp(58)
        content.add_widget(check)

        footer = Label(text="LOCAL USB LINK  ·  NO INTERNET REQUIRED", color=MUTED,
                       font_size="8sp", size_hint_y=None, height=dp(26))
        content.add_widget(footer)
        scroll.add_widget(content)
        root.add_widget(scroll)
        return root

    def _update_bg(self, widget, *_):
        self.bg_rect.pos = widget.pos
        self.bg_rect.size = widget.size

    def _panel_background(self, widget):
        with widget.canvas.before:
            Color(*CARD)
            rect = RoundedRectangle(pos=widget.pos, size=widget.size, radius=[dp(16)])
        widget.bind(pos=lambda obj, val: setattr(rect, "pos", val),
                    size=lambda obj, val: setattr(rect, "size", val))

    def section(self, text):
        return Label(text=text, color=RED, font_size="10sp", bold=True,
                     size_hint_y=None, height=dp(24), halign="left",
                     valign="middle", text_size=(None, None))

    def action_button(self, title, subtitle, callback, font_size=16, accent=False):
        btn = DaizButton(text=title, font_size=f"{font_size}sp", bold=True)
        btn.bind(on_release=callback)
        if accent:
            btn.color = RED
        return btn

    def run(self, command, app=None):
        self.status.text = "SENDING COMMAND..."
        message, ok = send_command(command, app)
        self.status.text = message.upper()
        self.status.color = GREEN if ok else WHITE
        self.status_dot.color = GREEN if ok else RED


if __name__ == "__main__":
    DaizControlApp().run()
