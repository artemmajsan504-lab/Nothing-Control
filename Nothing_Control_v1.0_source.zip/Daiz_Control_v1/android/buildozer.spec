[app]
title = Nothing Control
package.name = nothingcontrol
package.domain = com.daiz
source.dir = .
source.include_exts = py,png,jpg,kv
version = 1.0
requirements = python3,kivy
android.permissions = INTERNET
orientation = portrait
fullscreen = 0

[buildozer]
log_level = 2
warn_on_root = 1
